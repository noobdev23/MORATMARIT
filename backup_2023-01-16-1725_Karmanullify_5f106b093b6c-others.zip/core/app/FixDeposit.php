<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FixDeposit extends Model
{
    protected $guarded = ['id'];


}
