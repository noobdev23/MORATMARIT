<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoanPackage extends Model
{
    protected $guarded = ['id'];
}
