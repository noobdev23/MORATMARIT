<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FixDepositPak extends Model
{
    protected $guarded = ['id'];


}
