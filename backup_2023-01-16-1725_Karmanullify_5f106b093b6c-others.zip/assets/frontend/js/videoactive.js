$(function ($) {
  "use strict";
    $("#bgndVideo").YTPlayer();
});